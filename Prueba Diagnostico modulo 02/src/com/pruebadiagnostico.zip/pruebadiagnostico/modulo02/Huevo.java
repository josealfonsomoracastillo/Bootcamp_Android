package com.pruebadiagnostico.modulo02;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Huevo extends Carro{

 // 1- Agregar los atributos


	
	
	
	
 // 2- Agregar to String:
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Huevo [cantidadOcupantes=").append(cantidadOcupantes).append(", fechaIngreso=")
				.append(fechaIngreso).append(", cantidadColumnas=").append(cantidadColumnas).append(", cantidadFilas=")
				.append(cantidadFilas).append("]");
		return builder.toString();
	}
	
 // 3- Agregar constructor vacio:	
	
 // 4- Agregar constructor con atributos:	
	
	
// 5- Agregar Get and Set: 
	
	
	
	
	
}
